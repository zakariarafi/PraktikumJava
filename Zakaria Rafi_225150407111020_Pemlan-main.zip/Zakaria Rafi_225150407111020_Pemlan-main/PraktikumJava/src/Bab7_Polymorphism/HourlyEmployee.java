/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : Bab 7
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */
package Bab7_Polymorphism;
import Bab7_Polymorphism.Employee;
import java.util.Calendar;
import java.util.Date;

public class HourlyEmployee extends Employee {
    private double hourlyWage; // upah per jam
    private double hoursWorked; // jumlah jam tiap minggu

    public HourlyEmployee(String name, String noKTP, Date dateOfBirth, double hourlyWage, double hoursWorked) {
        super(name, noKTP, dateOfBirth);
        this.hourlyWage = hourlyWage;
        this.hoursWorked = hoursWorked;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public double earnings() {
        if (hoursWorked <= 40) {
            return hourlyWage * hoursWorked;
        } else {
            double overtimeHours = hoursWorked - 40;
            return (40 * hourlyWage) + (overtimeHours * hourlyWage * 1.5);
        }
    }

    public String toString() {
        return String.format("Hourly Employee\n%s\nHourly Wage: %.2f\nHours Worked: %.2f", super.toString(),
                getHourlyWage(), getHoursWorked());
    }
}