/*
* =================================================================
NAMA	      : ZAKARIA RAFI
NIM 	      : 225150407111020
KELAS	      : SI-B
BAB		   : Bab 5
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */
package Bab5_Inheritance;
public class Manusia {
   protected String nama, nik;
   private boolean jenisKelamin, menikah;
   private double tunjangan, pendapatan;
   
   public Manusia(String nama, String nik, boolean jenisKelamin, boolean menikah){
      this.nama = nama;
      this.nik = nik;
      this.jenisKelamin = jenisKelamin;
      this.menikah = menikah;
   }

   public void setNama(String nama){
      this.nama=nama;
   }

   public void setNik(String nik){
      this.nik = nik;
   }

   public String getJenisKelamin(){
      return this.jenisKelamin ? "Laki-laki":"Perempuan";
   }

   public String getNama(){
      return this.nama;
   }
   
   public String getNik(){
      return this.nik;
   }

   public double getTunjangan(){
      if(menikah){
         return jenisKelamin ? 25:20;
      }else{
         return 15;
      }
   }

   public double getPendapatan(){
      return getTunjangan();
   }
  

   public String toString(){
      return "nama           : " + getNama() + "\nNIK            : " + getNik() + "\nJenis Kelamin  : " + getJenisKelamin() + "\nPendapatan     : " + getPendapatan();
   }
}

