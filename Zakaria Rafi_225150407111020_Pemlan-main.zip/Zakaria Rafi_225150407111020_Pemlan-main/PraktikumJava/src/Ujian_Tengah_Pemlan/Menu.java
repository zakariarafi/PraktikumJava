/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : UTP
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */


public class Menu {
    private String nama;
    private int harga;

    public Menu(String nama, int harga) {
        this.nama = nama;
        this.harga = harga;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }
}