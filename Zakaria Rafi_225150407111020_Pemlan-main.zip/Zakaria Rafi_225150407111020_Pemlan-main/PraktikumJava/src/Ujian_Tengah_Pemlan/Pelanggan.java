/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : UTP
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */


public class Pelanggan {
    private String nama;

    public Pelanggan(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
}