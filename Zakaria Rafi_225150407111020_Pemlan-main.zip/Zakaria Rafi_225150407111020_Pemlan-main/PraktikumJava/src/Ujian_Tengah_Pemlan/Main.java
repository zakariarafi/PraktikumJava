/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : UTP
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */


public class Main {
    public static void main(String[] args) {
        Kasir kasir = new Kasir();
        kasir.jalankan();
    }
}