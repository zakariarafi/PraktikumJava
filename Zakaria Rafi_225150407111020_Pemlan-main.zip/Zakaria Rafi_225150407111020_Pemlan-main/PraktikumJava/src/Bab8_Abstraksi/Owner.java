/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : Bab 8
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */
package Bab8_Abstraksi;

public class Owner {
  private String name;

  // buat constructor
  public Owner(String name){
    this.name = name;
  } 

  // buat method getter untuk mendapatkan nilai name
  public String getName(){
    return name;
  }
}
