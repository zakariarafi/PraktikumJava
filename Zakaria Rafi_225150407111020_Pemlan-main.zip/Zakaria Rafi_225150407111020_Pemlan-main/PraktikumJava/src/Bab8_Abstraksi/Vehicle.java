/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : Bab 8
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */
package Bab8_Abstraksi;

public abstract class Vehicle {
  // buat variabel nama, tahun, dan rpm
  String nama;
  int tahun;
  double rpm;

  // buat sebuah method abstrak yang nantinya akan di override oleh class Car
  public abstract void data();
}