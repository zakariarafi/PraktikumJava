/*
* =================================================================
NAMA	      : ZAKARIA RAFI
NIM 	      : 225150407111020
KELAS	      : SI-B
BAB		   : Bab 6
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */
package Bab6_ArrayList;

public class Mahasiswa {
   private String nama;
  private String jurusan;
  private boolean status; // true=Menikah ; false=Lajang

  // Tambahkan constructor disini ...
  public Mahasiswa(String nama, String jurusan, boolean status){
    this.nama = nama;
    this.jurusan = jurusan;
    this.status = status;
  }
  public Mahasiswa(){

  }

  // Tambahkan method setter & getter disini ...
  public void setNama(String nama){
    this.nama = nama;
  }
  public void setJurusan(String jurusan){
    this.jurusan = jurusan;
  }
  public void setStatus(boolean status){
    this.status = status;
  }
  public String getNama(){
    return this.nama;
  }
  public String getJurusan(){
    return this.jurusan;
  }
  public boolean geStatus(){
    return this.status;
  }

}

