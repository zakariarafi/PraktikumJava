/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : Bab 1
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */
package Bab1_2_Inheritance_InstanceMethod;

import java.util.Scanner;
public class MainStudent {
   public static Scanner input = new Scanner(System.in);
   public static void main(String[] args) {
       
      Student anna = new Student();
      anna.setName("Anna");
      anna.setAddress("Malang");
      anna.setAge(20);
      anna.setMath(100);
      anna.setScience(89);
      anna.setEnglish(80);
      anna.displayMessage();

      

      //Menggunakan constructor lain
      System.out.println("==============================");
      Student chris = new Student("Chris", "Kediri",21);
      chris.setMath(70);
      chris.setScience(60
      );
      chris.setEnglish(90);
      chris.displayMessage();

      //Siswa dengan nama anna dirubah informasi alamat dan umurnya melalui constructor
      System.out.println("==============================");
      anna = new Student("anna", "Batu", 18);
      anna.setMath(100);
      anna.setScience(89);
      anna.setEnglish(80);
      anna.displayMessage();

      //Siswa dengan nama chris dirubah informasi alamat dan umurnya melalui method
      System.out.println("===============================");
      chris.setAddress("Surabaya");
      chris.setAge(22);
      chris.displayMessage();

      //Contoh penggunaan objek constructor dengan parameter nilai masing masing
      System.out.println("===============================");
      Student abdi = new Student(80, 90, 100);
      abdi.setName("Abdi");
      abdi.setAddress("Surabaya");
      abdi.setAge(18);
      abdi.displayMessage();


      
   
   }
}