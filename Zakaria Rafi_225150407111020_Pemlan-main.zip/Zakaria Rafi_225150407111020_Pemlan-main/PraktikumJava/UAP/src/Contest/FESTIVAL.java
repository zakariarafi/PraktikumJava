/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : UAP
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */
package Contest;

public class FESTIVAL extends TiketKonser {
    public FESTIVAL() {
        super("FESTIVAL", 2000000.0);
    }
}
