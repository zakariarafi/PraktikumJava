/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : UAP
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */
package Contest;

public class PemesananTiket {
    public static TiketKonser pilihTiket(int index) throws Exception {
        switch(index) {
            case 0:
                return new CAT8();
            case 1:
                return new CAT1();
            case 2:
                return new FESTIVAL();
            case 3:
                return new VIP();
            case 4:
                return new VVIP();    
            default:
                throw new Exception("Invalid index");
        }
    }
}
