
/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : UAP
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */

 package Contest;

public class VIP extends TiketKonser {
    public VIP() {
        super("VIP", 6000000.0);
    }
}
