/*
* =================================================================
NAMA	    : ZAKARIA RAFI
NIM 	    : 225150407111020
KELAS	    : SI-B
BAB		    : UAP
Pembimbing	: Adin Rama Ariyanto Putra dan Fahru Setiawan Iskandar

 * =================================================================
 */

package Contest;

public class VVIP extends TiketKonser {
    public VVIP() {
        super("VVIP", 10000000.0); // asumsi harga VVIP adalah 10,000,000. 
    }
}
