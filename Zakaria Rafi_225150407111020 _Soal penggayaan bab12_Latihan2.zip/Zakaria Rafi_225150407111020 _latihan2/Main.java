public class Main {
    public static void main(String[] args) {
        Perpustakaan perpustakaan = new Perpustakaan();

        Buku buku1 = new Buku("Algoritma Pemrograman", "Author1", 2019);
        Buku buku2 = new Buku("Sistem Jaringan Komputer", "Author2", 2021);

        Anggota anggota1 = new Anggota("Rendy", "001");
        Anggota anggota2 = new Anggota("Rihana", "002");

        perpustakaan.pinjamBuku(buku1, anggota1);
        perpustakaan.pinjamBuku(buku2, anggota2);
        perpustakaan.pinjamBuku(buku2, anggota1);  // ini akan menunjukkan bahwa buku2 sedang dipinjam

        perpustakaan.kembalikanBuku(buku1, anggota1);
        perpustakaan.kembalikanBuku(buku1, anggota1);  // ini akan menunjukkan bahwa buku1 tidak sedang dipinjam
    }
}
