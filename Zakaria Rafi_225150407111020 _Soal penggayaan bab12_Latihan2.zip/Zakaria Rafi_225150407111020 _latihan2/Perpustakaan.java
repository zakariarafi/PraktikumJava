public class Perpustakaan implements Peminjaman {
    @Override
    public void pinjamBuku(Buku buku, Anggota anggota) {
        if (!buku.getDipinjam()) {
            buku.setDipinjam(true);
            anggota.addRiwayatPeminjaman(buku);
            System.out.println("Buku '" + buku.getJudul() + "' berhasil dipinjam oleh " + anggota.getNama());
        } else {
            System.out.println("Buku '" + buku.getJudul() + "' sedang dipinjam oleh anggota lain.");
        }
    }

    @Override
    public void kembalikanBuku(Buku buku, Anggota anggota) {
        if (buku.getDipinjam()) {
            buku.setDipinjam(false);
            System.out.println("Buku '" + buku.getJudul() + "' berhasil dikembalikan oleh " + anggota.getNama());
        } else {
            System.out.println("Buku '" + buku.getJudul() + "' tidak sedang dipinjam oleh anggota tersebut.");
        }
    }
}
