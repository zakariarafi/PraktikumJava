import java.util.ArrayList;
import java.util.List;

public class Anggota {
    private String nama;
    private String nomorAnggota;
    private List<Buku> riwayatPeminjaman;

    // constructor, getter, setter, dan method lainnya
    public Anggota(String nama, String nomorAnggota){
        this.nama = nama;
        this.nomorAnggota = nomorAnggota;
        this.riwayatPeminjaman = new ArrayList<>();
    }
    
    public String getNama() {
        return nama;
    }
    
    public void addRiwayatPeminjaman(Buku buku) {
        this.riwayatPeminjaman.add(buku);
    }
    
    // methods lainnya jika diperlukan
}
