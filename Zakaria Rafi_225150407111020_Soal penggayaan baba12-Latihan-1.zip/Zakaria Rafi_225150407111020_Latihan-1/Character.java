public abstract class Character {
    public void move() {
        System.out.println("Character is moving...");
    }
}
