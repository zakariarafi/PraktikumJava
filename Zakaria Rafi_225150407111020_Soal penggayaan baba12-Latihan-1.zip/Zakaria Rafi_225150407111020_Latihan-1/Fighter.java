public class Fighter extends Character {
    @Override
    public void move() {
        System.out.println("Fighter is moving...");
    }
}
