public class App {
    public static void main(String[] args) {
        // Static polymorphism
        Hero hero = new Hero();
        hero.move();
        hero.move("forward");

        Enemy enemy = new Enemy();
        enemy.move();
        enemy.move(5);

        // Dynamic polymorphism
        Character charHero = new Hero();
        charHero.move();

        Character charEnemy = new Enemy();
        charEnemy.move();

        Character charWitch = new Witch();
        charWitch.move();

        Character charFighter = new Fighter();
        charFighter.move();

        // Dynamic polymorphism with casting
        Character charWitchCasting = new Witch();
        // Assuming Witch can be casted into Fighter. However, in reality it will throw ClassCastException.
        // In a proper design, these two classes should be siblings (both directly inherit from the same parent class) 
        // and Witch should have some properties that Fighter also has.
        // ((Fighter) charWitchCasting).move(); 
    }
}
