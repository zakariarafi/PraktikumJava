public class Witch extends Character {
    @Override
    public void move() {
        System.out.println("Witch is moving...");
    }
}
