package latihan;

public class App {
    public static void main(String[] args) {
        Asus laptop = new Asus();
        User user = new User();

        while (true) {
            System.out.println("=== APLIKASI INTERFACE ===");
            System.out.println("[1] Nyalakan Laptop");
            System.out.println("[2] Matikan Laptop");
            System.out.println("[3] Tambah Brightness");
            System.out.println("[4] Kurangi Brightness");
            System.out.println("[0] Keluar");

            int action = user.chooseAction();

            switch (action) {
                case 1:
                    laptop.powerOn();
                    break;
                case 2:
                    laptop.shutDown();
                    break;
                case 3:
                    laptop.brightnessUp();
                    break;
                case 4:
                    laptop.brightnessDown();
                    break;
                case 0:
                    System.exit(0);
                default:
                    System.out.println("Pilihan tidak valid");
            }
        }
    }
}

