package latihan;

import java.util.Scanner;

public class User {
    private Scanner scanner;

    public User() {
        this.scanner = new Scanner(System.in);
    }

    public int chooseAction() {
        System.out.println("Pilih aksi>");
        return scanner.nextInt();
    }
}
