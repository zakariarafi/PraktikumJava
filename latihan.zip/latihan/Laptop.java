package latihan;

public interface Laptop {
    int max_brightness = 100;
    int min_brightness = 0;

    void powerOn();

    void shutDown();

    void brightnessUp();

    void brightnessDown();

    int getBrightness();
}
